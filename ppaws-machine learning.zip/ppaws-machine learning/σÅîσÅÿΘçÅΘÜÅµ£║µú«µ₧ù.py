import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.inspection import PartialDependenceDisplay
import os

# 设置字体和负号显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 优化随机森林模型
def optimize_random_forest(X, y):
    n_est = np.linspace(10, 150, 15)
    max_dep = np.linspace(1, 20, 20)
    seed = 999
    best_rf_reg = None
    best_val_r2 = -np.inf

    while True:
        train_x, val_x, train_y, val_y = train_test_split(X, y, test_size=0.2, random_state=seed)
        for estimators in n_est:
            for depth in max_dep:
                rf_reg = RandomForestRegressor(random_state=seed).set_params(
                    n_estimators=int(estimators),
                    max_depth=int(depth)
                )
                rf_reg.fit(train_x, train_y)

                val_pred = rf_reg.predict(val_x)
                val_r2 = r2_score(val_y, val_pred)

                if val_r2 > best_val_r2:
                    best_rf_reg = rf_reg
                    best_val_r2 = val_r2

        if best_val_r2 > 0.7:
            break
        else:
            seed -= 2
            print(f"Adjusting seed: {seed}")

    return best_rf_reg

# 安全处理文件名的函数
def sanitize_filename(filename):
    return "".join([c if c.isalnum() or c in [' ', '.', '_', '-'] else '_' for c in filename])

# 读取数据
data = pd.read_excel(r"D:\北林材料\11.25号数据.xlsx", sheet_name=0)  # 替换为你的实际数据路径
num_outputs = 5
features = data.iloc[:, :-num_outputs]
labels = data.iloc[:, -num_outputs:]

# 创建一个输出目录
output_dir = r"C:\Users\86133\Desktop\双变量依赖图"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 为每个目标变量单独训练随机森林模型并生成双变量偏依赖图
for i in range(len(labels.columns)):
    sanitized_label = sanitize_filename(labels.columns[i])

    # 单独为当前目标变量训练随机森林模型
    best_rf_model = optimize_random_forest(features.values, labels.iloc[:, i].values)

    for j, feature_1 in enumerate(features.columns):
        for feature_2 in features.columns[j + 1:]:
            sanitized_feature_1 = sanitize_filename(feature_1)
            sanitized_feature_2 = sanitize_filename(feature_2)

            # 尝试绘制双变量偏依赖图
            try:
                fig, ax = plt.subplots(figsize=(12, 8))
                pdp_display = PartialDependenceDisplay.from_estimator(
                    best_rf_model, features, [(feature_1, feature_2)], ax=ax, grid_resolution=5  # 设置网格密度为5
                )

                # 提取偏依赖图数据，确保网格数据和图像一致
                grid_values_1 = pdp_display.pd_results[0].grid_values[0]
                grid_values_2 = pdp_display.pd_results[0].grid_values[1]
                partial_dependence_values = pdp_display.pd_results[0].average

                # 创建一个DataFrame来存储网格值和偏依赖值
                partial_dep_data = {
                    f'{feature_1}_grid': np.repeat(grid_values_1, len(grid_values_2)),
                    f'{feature_2}_grid': np.tile(grid_values_2, len(grid_values_1)),
                    f'{labels.columns[i]}_partial_dependence': partial_dependence_values.flatten()
                }
                partial_dep_df = pd.DataFrame(partial_dep_data)

                # 保存偏依赖数据到Excel
                excel_path = os.path.join(output_dir,
                                          f'partial_dependence_data_{sanitized_label}_{sanitized_feature_1}_{sanitized_feature_2}.xlsx')
                partial_dep_df.to_excel(excel_path, index=False)
                print(f"Excel file saved to: {excel_path}")

                # 设置标题和调整图像
                plt.suptitle(f'Partial Dependence Plot for {labels.columns[i]} - {feature_1} & {feature_2}', fontsize=16)
                plt.subplots_adjust(top=0.9)

                # 保存图像
                img_path = os.path.join(output_dir,
                                        f'partial_dependence_{sanitized_label}_{sanitized_feature_1}_{sanitized_feature_2}.png')
                plt.savefig(img_path, format='png', dpi=300)
                plt.close()
                print(f"Image file saved to: {img_path}")

            except ValueError as e:
                print(f"Skipping features {feature_1} and {feature_2} due to error: {e}")

# 输出文件保存路径
print(f"Partial Dependence Plot and data have been saved to: {output_dir}")
