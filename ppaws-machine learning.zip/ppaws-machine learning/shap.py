import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import shap
import matplotlib.pyplot as plt
import matplotlib
from itertools import combinations  # 导入组合模块

# 设置字体为 SimHei 以支持中文字符和特殊符号
matplotlib.rcParams['font.family'] = 'SimHei'
matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 定义保存输出的目录
output_dir = r'C:\Users\86133\Desktop\新建文件夹'

# 自动创建目录（如果不存在）
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 读取数据
data = pd.read_excel(r"D:\北林材料\11.25号数据.xlsx", header=0, engine='openpyxl')

# 假设最后五列是目标变量，其他是特征
X = data.iloc[:, :-5]  # 特征
y = data.iloc[:, -5:]  # 目标变量

# 对每个目标变量训练模型并生成 SHAP 分析
for i in range(y.shape[1]):
    target = y.iloc[:, i]  # 提取每个目标变量
    target_name = y.columns[i]  # 获取目标变量名称

    # 分割数据集
    X_train, X_test, y_train, y_test = train_test_split(X, target, test_size=0.2, random_state=42)

    # 训练 RandomForest 模型
    rf_reg = RandomForestRegressor(n_estimators=100, max_depth=6, random_state=42)
    rf_reg.fit(X_train, y_train)

    # 生成 SHAP 值
    explainer = shap.TreeExplainer(rf_reg)
    shap_values = explainer.shap_values(X)

    # 绘制 SHAP 蜂群图
    plt.figure(figsize=(12, 8))
    shap.summary_plot(shap_values, X, plot_type="violin", show=False)
    plt.title(f'SHAP Summary Plot for Target {target_name}')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f'SHAP_Beeswarm_Target_{i + 1}.svg'), format='svg', dpi=600)
    plt.close()

    # 计算并保存平均绝对 SHAP 值
    mean_abs_shap_values = np.abs(shap_values).mean(axis=0)
    mean_abs_shap_df = pd.DataFrame({
        'Feature': X.columns,
        'Mean_Abs_SHAP_Value': mean_abs_shap_values
    }).sort_values(by='Mean_Abs_SHAP_Value', ascending=False)

    mean_abs_shap_df.to_excel(os.path.join(output_dir, f'Mean_Abs_SHAP_Target_{i + 1}.xlsx'), index=False,
                              engine='openpyxl')

    print(f"SHAP analysis completed for target variable {target_name}")

    # 绘制所有单依赖图并保存
    for feature_name in X.columns:
        plt.figure(figsize=(10, 6))
        shap.dependence_plot(feature_name, shap_values, X, show=False)
        plt.title(f'SHAP Dependence Plot for Target {target_name} - Feature {feature_name}')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'SHAP_Single_Dependency_Target_{i + 1}_{feature_name}.png'), format='png', dpi=600)
        plt.close()

    # 绘制所有双依赖图并保存
    feature_combinations = combinations(X.columns, 2)  # 生成所有两两特征组合
    for feature_pair in feature_combinations:
        plt.figure(figsize=(10, 6))
        # 使用 feature_pair[0] 作为主要特征，feature_pair[1] 作为 interaction_index
        shap.dependence_plot(feature_pair[0], shap_values, X, show=False, interaction_index=feature_pair[1])
        plt.title(f'SHAP Double Dependency Plot for Target {target_name} - Features {feature_pair[0]} & {feature_pair[1]}')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'SHAP_Double_Dependency_Target_{i + 1}_{feature_pair[0]}_{feature_pair[1]}.png'), format='png', dpi=600)
        plt.close()

    # 绘制水滴图（选择一个样本来显示）
    for j in range(5):  # 默认选择前5个测试样本
        plt.figure(figsize=(10, 6))
        shap.waterfall_plot(shap_values[j], max_display=10)
        plt.title(f'SHAP Waterfall Plot for Target {target_name} - Sample {j + 1}')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'SHAP_Waterfall_Target_{i + 1}_Sample_{j + 1}.png'), format='png', dpi=600)
        plt.close()

print("All SHAP single, double dependency plots, and waterfall plots saved successfully in SVG format.")
