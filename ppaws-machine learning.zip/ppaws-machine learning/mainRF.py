import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import matplotlib.pyplot as plt
import time
from scipy.interpolate import griddata

# 定义存储图片和结果的文件夹路径
output_dir = r'C:\Users\86133\Desktop\新建文件夹'
# 自动创建文件夹（如果不存在）
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

def optimize_random_forest(X, y):
    # 定义参数网格
    n_est = np.linspace(10, 150, 15)
    max_dep = np.linspace(1, 20, 20)
    seed = 999
    while True:
        results = []
        train_x, val_x, train_y, val_y = train_test_split(X, y, test_size=0.2, random_state=seed)
        for estimators in n_est:
            for depth in max_dep:
                # 初始化一个随机森林回归器
                rf_reg = RandomForestRegressor(random_state=seed).set_params(n_estimators=int(estimators),
                                                                             max_depth=int(depth))
                rf_reg.fit(train_x, train_y)
                val_pred = rf_reg.predict(val_x)
                val_r2 = r2_score(y_true=val_y, y_pred=val_pred)
                val_test_mse = mean_squared_error(y_true=val_y, y_pred=val_pred)
                val_mae = mean_absolute_error(y_true=val_y, y_pred=val_pred)

                # 打印当前参数及其性能（基于测试集）
                print(f"Testing estimators={estimators}, depth={depth}")
                print(f"Validation R2: {val_r2}, Validation MSE: {val_test_mse}, Validation MAE: {val_mae}")
                # 记录结果
                results.append({
                    'est': estimators,
                    'dep': depth,
                    'val_r2': val_r2,
                    'val_test_mse': val_test_mse ** 0.5,
                    'val_mae': val_mae,
                    'seed': seed
                })
        # 将结果转换为DataFrame
        results_df = pd.DataFrame(results)
        best_parameters = results_df.loc[results_df['val_r2'].idxmax()]
        # 如果满足条件，停止循环
        if best_parameters['val_r2'] > 0.3:
            return results_df
        else:
            seed = seed - 2
            print(seed)
            time.sleep(2)

# 读取数据
data = pd.read_excel(r"D:\北林材料\工作簿2.xlsx", header=0, engine='openpyxl')

# 假设最后五列是目标变量，其他列是特征变量
X = data.iloc[:, :-5]  # 前面所有列（除最后五列外）作为特征变量
y = data.iloc[:, -5:]  # 最后五列作为目标变量

# 针对每个目标变量进行训练
for i in range(y.shape[1]):
    target = y.iloc[:, i]  # 提取每一个目标变量

    # 按照7:1:2的比例划分数据集，首先划分出训练集和临时集（验证集+测试集）
    X_train, X_temp, y_train, y_temp = train_test_split(X, target, test_size=0.3, random_state=42)  # 70% 训练集，30% 临时集
    # 然后将临时集再划分为验证集和测试集（1:2）
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=2 / 3, random_state=42)  # 33%验证集，67% 测试集

    results_df = optimize_random_forest(X_train, y_train)

    # 保存结果
    results_df.to_excel(os.path.join(output_dir, f'RF_results_feature_{i + 1}.xlsx'), index=False, engine='openpyxl')

    # 寻找最大测试集 R2 的点
    max_R2_index = results_df['val_r2'].idxmax()
    max_R2_point = results_df.loc[max_R2_index]
    n_est = np.linspace(10, 150, 15)
    max_dep = np.linspace(1, 20, 20)
    n_est, max_dep = np.meshgrid(n_est, max_dep)

    # 进行插值，使用测试集 R²
    R_i = griddata((results_df['est'], results_df['dep']), results_df['val_r2'], (n_est, max_dep), method='cubic')

    # 绘制等高热力图，基于测试集 R²
    plt.figure(figsize=(10, 8))
    contour = plt.contourf(n_est, max_dep, R_i, levels=50, cmap='viridis')
    cbar = plt.colorbar(contour)
    cbar.set_label('Validation R2 (Test Set)')
    plt.title('Heatmap of Validation R2 (Test Set)')
    plt.xlabel('n_estimators')
    plt.ylabel('max_depth')

    # 在图中标记最优点
    plt.scatter(max_R2_point['est'], max_R2_point['dep'], color='red', s=50)  # 使用红色标记最优点
    plt.annotate('Maximum R2_mean', (max_R2_point['est'], max_R2_point['dep']), textcoords="offset points",
                 xytext=(0, 10), ha='center')

    # 保存图像为svg
    plt.savefig(os.path.join(output_dir, f'RF_R2_{i}.svg'), format='svg', dpi=300)

    # 创建并训练随机森林模型
    rf_reg = RandomForestRegressor(random_state=int(max_R2_point['seed'])).set_params(
        n_estimators=int(max_R2_point['est']), max_depth=int(max_R2_point['dep']))
    rf_reg.fit(X_train, y_train)

    # 预测
    y_train_pred = rf_reg.predict(X_train)
    y_val_pred = rf_reg.predict(X_val)
    y_test_pred = rf_reg.predict(X_test)

    # 计算训练集、验证集和测试集上的性能
    train_r2 = r2_score(y_true=y_train, y_pred=y_train_pred)
    train_mse = mean_squared_error(y_true=y_train, y_pred=y_train_pred) ** 0.5
    train_mae = mean_absolute_error(y_true=y_train, y_pred=y_train_pred)

    val_r2 = r2_score(y_true=y_val, y_pred=y_val_pred)
    val_mse = mean_squared_error(y_true=y_val, y_pred=y_val_pred) ** 0.5
    val_mae = mean_absolute_error(y_true=y_val, y_pred=y_val_pred)

    test_r2 = r2_score(y_true=y_test, y_pred=y_test_pred)
    test_mse = mean_squared_error(y_true=y_test, y_pred=y_test_pred) ** 0.5
    test_mae = mean_absolute_error(y_true=y_test, y_pred=y_test_pred)

    # 创建训练集、验证集和测试集结果的 DataFrame，包含 R², MSE 和 MAE
    train_results = pd.DataFrame({
        'Train_True': y_train,
        'Train_Pred': y_train_pred,
        'Relative_Error': np.abs((y_train - y_train_pred) / y_train),
        'Train_R2': [train_r2] * len(y_train),
        'Train_MSE': [train_mse] * len(y_train),
        'Train_MAE': [train_mae] * len(y_train)
    })
    val_results = pd.DataFrame({
        'Val_True': y_val,
        'Val_Pred': y_val_pred,
        'Relative_Error': np.abs((y_val - y_val_pred) / y_val),
        'Val_R2': [val_r2] * len(y_val),
        'Val_MSE': [val_mse] * len(y_val),
        'Val_MAE': [val_mae] * len(y_val)
    })
    test_results = pd.DataFrame({
        'Test_True': y_test,
        'Test_Pred': y_test_pred,
        'Relative_Error': np.abs((y_test - y_test_pred) / y_test),
        'Test_R2': [test_r2] * len(y_test),
        'Test_MSE': [test_mse] * len(y_test),
        'Test_MAE': [test_mae] * len(y_test)
    })

    # 保存训练集、验证集和测试集结果为 Excel 文件
    train_results.to_excel(os.path.join(output_dir, f'RF_train_results_feature_{i + 1}.xlsx'), index=False,
                           engine='openpyxl')
    val_results.to_excel(os.path.join(output_dir, f'RF_val_results_feature_{i + 1}.xlsx'), index=False,
                         engine='openpyxl')
    test_results.to_excel(os.path.join(output_dir, f'RF_test_results_feature_{i + 1}.xlsx'), index=False,
                          engine='openpyxl')

    # 绘制实际值与预测值的散点图（基于测试集）
    plt.figure(figsize=(10, 8))
    plt.scatter(y_train, y_train_pred, color='blue', label='Train Data')
    plt.scatter(y_val, y_val_pred, color='green', label='Validation Data')
    plt.scatter(y_test, y_test_pred, color='red', label='Test Data')
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=4)
    plt.xlabel('Actual')
    plt.ylabel('Predicted')
    plt.title('Fit of RF Model on Train, Validation, and Test Sets')
    plt.legend()
    # 标记测试集 R², MSE, MAE
    plt.text(4, 6, f'Test R²: {test_r2:.2f}', fontsize=9, verticalalignment='top')
    plt.text(4, 7, f'Test MSE: {test_mse:.2f}', fontsize=9, verticalalignment='top')
    plt.text(4, 8, f'Test MAE: {test_mae:.2f}', fontsize=9, verticalalignment='top')
    # 保存图像为svg
    plt.savefig(os.path.join(output_dir, f'RF_Model_Fit_{i}_R2.svg'), format='svg', dpi=300)

    # 获取特征重要性
    importances = rf_reg.feature_importances_

    # 创建特征重要性表格
    feature_importance_df = pd.DataFrame({
        'Feature': X.columns,
        'Importance': importances
    })

    # 按照重要性排序
    feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)

    # 保存特征重要性表格为 Excel 文件
    feature_importance_df.to_excel(os.path.join(output_dir, f'RF_feature_importance_{i + 1}.xlsx'), index=False, engine='openpyxl')

    # 绘制特征重要性条形图
    plt.figure(figsize=(10, 8))
    plt.barh(feature_importance_df['Feature'], feature_importance_df['Importance'], color='skyblue')
    plt.xlabel('Importance')
    plt.title(f'Feature Importance for Target Variable {i + 1}')
    plt.tight_layout()

    # 保存特征重要性图像为svg
    plt.savefig(os.path.join(output_dir, f'RF_feature_importance_{i + 1}.svg'), format='svg', dpi=300)

    # 显示图像
    plt.show()
